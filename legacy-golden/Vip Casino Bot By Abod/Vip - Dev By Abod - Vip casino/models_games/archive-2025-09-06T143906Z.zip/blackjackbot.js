const mongoose = require('mongoose');

const blackjackbotSchema = new mongoose.Schema({
    messageId: String,
    userId: String,
    playerHand: Array,
    botHand: Array,
    deckId: { type: Number }, // Add this line
    betAmount: Number,
    gameActive: Boolean,
    canDouble: Boolean,
    withdrawRefund: Number,
    withdrawRequested: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
    bj_wins: { type: Number, default: 0 },
    bj_losses: { type: Number, default: 0 },
    bj_draws: { type: Number, default: 0 },
    bj_withdraws: { type: Number, default: 0 },
    bj_coins_won: { type: Number, default: 0 },
    bj_coins_lost: { type: Number, default: 0 },
    bj_coins_refunded: { type: Number, default: 0 }
});
module.exports = mongoose.model('blackjackbot', blackjackbotSchema);